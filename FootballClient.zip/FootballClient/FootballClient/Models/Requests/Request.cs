﻿namespace FootballClient.Models.Requests
{
    class Request : Message
    {
        public Request(int id, Player player) : base(id, player)
        {

        }
    }
}
