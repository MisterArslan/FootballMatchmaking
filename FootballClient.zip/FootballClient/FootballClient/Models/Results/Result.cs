﻿namespace FootballClient.Models.Results
{
    class Result : Message
    {
        public Result(int id, Player player) : base(id, player)
        {
        }
    }
}
